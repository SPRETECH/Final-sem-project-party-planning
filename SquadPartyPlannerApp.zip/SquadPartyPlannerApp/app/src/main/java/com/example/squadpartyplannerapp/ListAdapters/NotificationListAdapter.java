package com.example.squadpartyplannerapp.ListAdapters;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.example.squadpartyplannerapp.ModelClass.NotificationData;
import com.example.squadpartyplannerapp.NotificationActivity;
import com.example.squadpartyplannerapp.R;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.ArrayList;

public class NotificationListAdapter extends RecyclerView.Adapter<NotificationListAdapter.ItemViewHolder> {

    ArrayList<NotificationData> notificationDataArrayList;
    Context context;
    NotificationData data;
    String uid;
    FirebaseAuth firebaseAuth;
    FirebaseDatabase firebaseDatabase;
    DatabaseReference databaseReference;

    public NotificationListAdapter(ArrayList<NotificationData> notificationDataArrayList, NotificationActivity notificationActivity) {
        this.notificationDataArrayList = notificationDataArrayList;
        context = notificationActivity;
    }

    @NonNull
    @Override
    public ItemViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.notification_list_item,parent,false);
        return new ItemViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull ItemViewHolder holder, final int position) {
        data = notificationDataArrayList.get(position);
        holder.notificationTitle.setText("Invitation");
        holder.notificationMessage.setText(notificationDataArrayList.get(position).getMessage());
        holder.bind(data);
        holder.itemView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                boolean expanded = data.isExpanded();
                data.setExpanded(!expanded);
                notifyItemChanged(position);
            }
        });
        holder.Accept.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Toast.makeText(context,"Accepted!",Toast.LENGTH_LONG).show();
                notificationDataArrayList.remove(position);
                setStatus_in_Notification("Accepted");
                notifyDataSetChanged();
            }
        });
        holder.Reject.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Toast.makeText(context,"Rejected!",Toast.LENGTH_LONG).show();
                notificationDataArrayList.remove(position);
                setStatus_in_Notification("Rejected");
                notifyDataSetChanged();
            }
        });
    }

    @Override
    public int getItemCount() {
        return notificationDataArrayList.size();
    }

    public void setStatus_in_Notification(final String status)
    {
        firebaseAuth = FirebaseAuth.getInstance();
        uid = firebaseAuth.getCurrentUser().getUid();
        firebaseDatabase = FirebaseDatabase.getInstance();
        databaseReference = firebaseDatabase.getReference().child("Invitations");

        databaseReference.addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                if(dataSnapshot.exists())
                {
                    for(DataSnapshot ds : dataSnapshot.getChildren())
                    {
                        for(DataSnapshot ds1 : ds.getChildren())
                        {
                            if(ds1.child("Receiver_UID").getValue().toString().contentEquals(uid))
                            {
                                if(ds1.child("Status").getValue().toString().contentEquals("Pending"))
                                {
                                    ds1.child("Status").getRef().setValue(status);
                                }
                            }
                        }
                    }
                }
            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {
                Toast.makeText(context,databaseError.getMessage(),Toast.LENGTH_LONG).show();
            }
        });
    }

    public class ItemViewHolder extends RecyclerView.ViewHolder {

        TextView notificationTitle,notificationMessage;
        Button Accept,Reject;
        LinearLayout buttonLayout;

        public ItemViewHolder(@NonNull View itemView) {
            super(itemView);
            notificationTitle = itemView.findViewById(R.id.notification_title);
            notificationMessage = itemView.findViewById(R.id.notification_message);
            Accept = itemView.findViewById(R.id.accept_button_notification);
            Reject = itemView.findViewById(R.id.reject_button_notification);
            buttonLayout = itemView.findViewById(R.id.linear_button_notification);
        }
        private void bind(NotificationData notificationData) {
            boolean expanded = notificationData.isExpanded();

            buttonLayout.setVisibility(expanded ? View.VISIBLE : View.GONE);
        }
    }
}
